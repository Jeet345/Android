package com.example.a05;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class dbo extends SQLiteOpenHelper {

    public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "Employee", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not exists emp(id integer primary key autoincrement,name text,age integer,designation text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        onCreate(db);
    }

    public void addData(String name, int age, String designation) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("age", age);
        cv.put("designation", designation);
        db.insert("emp", null, cv);
        db.close();
    }

    public boolean updateData(String id, String name, int age, String designation) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("age", age);
        cv.put("designation", designation);
        Cursor cursor = db.rawQuery("select * from emp where id = ?", new String[]{id});

        if (cursor.getCount() > 0) {
            int result = db.update("emp", cv, "id=?", new String[]{id});
            if (result == 1) {
                db.close();
                return true;
            }
        }
        db.close();
        return false;
    }

    public boolean removeData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from emp where id = ?", new String[]{id});

        if (cursor.getCount() > 0) {
            int result = db.delete("emp", "id=?", new String[]{id});
            if (result == 1) {
                db.close();
                return true;
            }
        }
        db.close();
        return false;
    }


    public Cursor fetchAllData() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from emp", null, null);
        return cursor;
    }
}

